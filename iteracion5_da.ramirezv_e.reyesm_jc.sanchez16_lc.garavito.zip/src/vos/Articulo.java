package vos;


public interface Articulo {
	
	public abstract String getNombre();
	public abstract String getRestaurante();
	public abstract double getPrecio();
	public abstract String getCambios();

}
